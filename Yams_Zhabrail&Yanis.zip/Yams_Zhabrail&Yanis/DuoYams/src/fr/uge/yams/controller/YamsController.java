package fr.uge.yams.controller;

import java.util.Scanner;

import fr.uge.yams.model.*;
import fr.uge.yams.view.ConsoleView;

public class YamsController {

    private final Scanner scanner;
    private final ConsoleView view;

    public YamsController(Scanner scanner, ConsoleView view) {
        this.scanner = scanner;
        this.view = view;
    }

    public void startGame() {
        view.displayMessage("Welcome to Yams!");
        view.displayMessage("Player 1, please enter your name:");
        String name1 = scanner.nextLine();
        view.displayMessage("Player 2, please enter your name:");
        String name2 = scanner.nextLine();

        ScoreSheet scoreSheet1 = new ScoreSheet();
        ScoreSheet scoreSheet2 = new ScoreSheet();

        for (int round = 0; round < 7; round++) {
            playTurn(name1, scoreSheet1);
            playTurn(name2, scoreSheet2);
        }

        view.displayFinalScore(scoreSheet1.scoreTotal(), scoreSheet2.scoreTotal(), name1, name2);
    }

    private void playTurn(String playerName, ScoreSheet scoreSheet) {
        view.displayMessage("\n==> " + playerName + "'s turn");
        Board board = new Board();
        view.displayBoard(board);

        for (int reroll = 0; reroll < 2; reroll++) { // 2 relances max
            int[] diceToReroll = view.askDiceToReroll(scanner);
            if (diceToReroll.length == 0) {
                break; // arrêt des relances
            }
            board.reroll(diceToReroll);
            view.displayBoard(board);
        }

        while (true) {
            try {
                String input = view.askCombination(scanner);
                Combination combination = parseCombination(input);

                if (scoreSheet.isCombinationUsed(combination)) {
                    view.displayMessage("This combination has already been used. Choose another one.");
                    continue;
                }

                boolean updated = scoreSheet.updateScore(combination, board, scanner);
                if (updated) {
                    break; // ok on sort de la boucle
                }
                // sinon on redemande (updateScore a affiché le message)
            } catch (IllegalArgumentException e) {
                view.displayMessage("Invalid combination. Try again.");
            }
        }


        view.displayScoreSheet(scoreSheet);
    }

    private Combination parseCombination(String input) {
        return switch (input.toUpperCase()) {
            case "T" -> new ThreeOfAKind();
            case "F" -> new FullHouse();
            case "C" -> new ChanceCombination();
            case "4" -> new FourOfAKind();
            case "S" -> new SmallStraight();
            case "L" -> new LargeStraight();
            case "Y" -> new YamsCombination();
            default -> throw new IllegalArgumentException("Invalid combination");
        };
    }
}
