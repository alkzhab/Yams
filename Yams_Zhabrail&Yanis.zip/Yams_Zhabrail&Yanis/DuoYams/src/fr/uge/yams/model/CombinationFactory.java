package fr.uge.yams.model;

public class CombinationFactory {
    public static Combination parse(String code) {
        return switch (code) {
            case "T" -> new ThreeOfAKind();
            case "F" -> new FullHouse();
            case "C" -> new ChanceCombination();
            case "4" -> new FourOfAKind();
            case "S" -> new SmallStraight();
            case "L" -> new LargeStraight();
            case "Y" -> new YamsCombination();
            default -> throw new IllegalArgumentException("Invalid combination code: " + code);
        };
    }
}
