package fr.uge.yams.model;

import java.util.HashMap;
import java.util.Objects;
import java.util.Scanner;

public class ScoreSheet {

    private final HashMap<Combination, Integer> scoreMap = new HashMap<>();

    /**
     * Tente de mettre à jour le score avec la combinaison fournie.
     * Retourne true si l'opération a réussi (score ajouté ou sacrifié),
     * false si l'utilisateur ne veut pas sacrifier une combinaison invalide.
     */
    public boolean updateScore(Combination combination, Board board, Scanner scanner) {
        Objects.requireNonNull(combination);

        if (isCombinationUsed(combination)) {
            throw new IllegalArgumentException("This combination has already been scored.");
        }

        if (!combination.isValid(board)) {
            System.out.println("This combination is not valid. You may choose to sacrifice the case (0 points).");
            System.out.println("Do you want to sacrifice this combination? (y/n)");
            String sacrifice = scanner.nextLine();
            if (sacrifice.equalsIgnoreCase("y")) {
                scoreMap.put(combination, 0);  // Sacrifice case
                return true;
            } else {
                System.out.println("Okay, please choose another combination.");
                return false;  // Important, redemander
            }
        } else {
            scoreMap.put(combination, combination.score(board));
            return true;
        }
    }


    public void updateScoreIA(Combination combination, Board board, Scanner scanner) {
        Objects.requireNonNull(combination);

        if (!combination.isValid(board)) {
            scoreMap.put(combination, 0); // Sacrifice auto
        } else if (isCombinationUsed(combination)) {
            throw new IllegalArgumentException("This combination has already been scored.");
        } else {
            scoreMap.put(combination, combination.score(board));
        }
    }

    public int scoreTotal() {
        return scoreMap.values().stream().mapToInt(Integer::intValue).sum();
    }

    public boolean isCombinationUsed(Combination combination) {
        return scoreMap.containsKey(combination);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        scoreMap.forEach((combination, score) -> {
            builder.append(combination.toString())
                   .append(": ")
                   .append(score)
                   .append("\n");
        });
        return builder.toString();
    }

    public void printFinalScore() {
        System.out.println("Final score: " + scoreTotal());
        System.out.println("Thanks for playing!");
    }
}
