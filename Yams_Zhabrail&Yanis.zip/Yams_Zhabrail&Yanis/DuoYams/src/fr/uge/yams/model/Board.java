package fr.uge.yams.model;

import java.util.ArrayList;
import java.util.List;

public class Board {

	private final ArrayList<Dice> fiveDice = new ArrayList<Dice>();

	public Board() {
		for (var i = 1; i <= 5; i++) {
			fiveDice.add(new Dice());
		}
	}

	@Override
	public String toString() {
		var builder = new StringBuilder();
		for (var i = 1; i <= 5; i++) {
			builder.append(fiveDice.get(i - 1).toString());
		}
		builder.append("\n").append("-----------------\n");

		return builder.toString();
	}

	public void reroll(int[] positions) {
	    for (int pos : positions) {
	        if (pos < 1 || pos > 5) {
	            throw new IllegalArgumentException("Invalid dice position: " + pos);
	        }
	        fiveDice.set(pos - 1, new Dice());
	    }
	}


	public static void main(String[] args) {

		var board = new Board();
		System.out.println(board);
		int[] positions = {2}; 
        board.reroll(positions);
		System.out.println(board);
	}
	
	public int sumOfDice() {
	    return fiveDice.stream().mapToInt(Dice::value).sum();
	}
	
	public List<Dice> getDice() {
        return new ArrayList<>(fiveDice);
    }


}