package fr.uge.yams.view;

import java.util.Scanner;

import fr.uge.yams.model.Board;
import fr.uge.yams.model.ScoreSheet;

public class ConsoleView {

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void displayBoard(Board board) {
        System.out.println(board);
    }

    public int[] askDiceToReroll(Scanner scanner) {
        while (true) {
            System.out.println("Which dice do you want to reroll? Enter numbers separated by spaces (0 to stop):");
            var input = scanner.nextLine();
            var parts = input.trim().split("\\s+");
            if (parts.length == 1 && parts[0].equals("0")) {
                return new int[0];
            }
            try {
                int[] choices = new int[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    choices[i] = Integer.parseInt(parts[i]);
                    if (choices[i] < 1 || choices[i] > 5) {
                        throw new IllegalArgumentException();
                    }
                }
                return choices;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter numbers between 1 and 5, or '0' to stop.");
            }
        }
    }

    public String askCombination(Scanner scanner) {
        System.out.println("Please choose a combination (T, F, C, 4, S, L, Y):");
        return scanner.nextLine();
    }

    public void displayScoreSheet(ScoreSheet scoreSheet) {
        System.out.println(scoreSheet);
    }

    public void displayFinalScore(int score1, int score2, String name1, String name2) {
        System.out.println("Game over!");
        System.out.println(name1 + "'s total score: " + score1);
        System.out.println(name2 + "'s total score: " + score2);
        if (score1 > score2) {
            System.out.println(name1 + " wins!");
        } else if (score2 > score1) {
            System.out.println(name2 + " wins!");
        } else {
            System.out.println("It's a tie!");
        }
    }
}
