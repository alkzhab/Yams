package fr.uge.yams;

import java.util.Scanner;
import fr.uge.yams.controller.YamsController;
import fr.uge.yams.view.ConsoleView;

public class Yams {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ConsoleView view = new ConsoleView();
        YamsController controller = new YamsController(scanner, view);
        controller.startGame();
    }
}
