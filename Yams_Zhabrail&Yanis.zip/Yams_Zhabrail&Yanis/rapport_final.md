# Rapport Final – Projet Java BUT1

## Page de garde

**Titre du projet** : Yams
**Noms des étudiants** : Alkhastov Zhabrail
**Groupe / TD / TP** : TD B
**Date de rendu** : 09/06/2025

---

## Introduction

> Présentez en quelques lignes le projet et le scénario suivi :
- Contexte du projet :
    Ce projet consiste à réaliser le jeu Yams en Java, dans un premier temps en mode console, puis en mode graphique avec JavaFX.
    
- Objectifs principaux :
    - Implémenter les règles complètes du Yams
    - Permettre un mode solo contre une IA et un mode 2 joueurs
    - Créer une interface graphique 
    - Ajouter un mode bonus
    
- Organisation et répartition du travail :

Phase 1 et 2 : implémentation du jeu Java console.

    Zhabrail : Développement du jeu Yams en mode solo contre l'IA
    Yanis : Développement du jeu Yams en mode 2 joueurs
    
Phase 3 : interface graphique avec JavaFX

    Conception des interfaces sur Figma pour avoir un prototypage visuel
    Implémentation de l'interface graphique sous JavaFX
    La répartition du travail est restée identique :
        Zhabrail : intégration du mode solo dans l'interface
        Yanis : intégration du mode 2 joueurs
    Ajout du mode bonus :
        Création des cartes bonus sur Figma
        Intégration de ces cartes dans le mode 2 joueurs

## 1.  Bilan Phase 1

- Scénario : B/C (approfondissement)
- Priorités de cette dernière phase :
  Avant d'approfondir le projet et de passer à la réalisation complète de l'interface graphique, nous devions revenir sur plusieurs points techniques, corriger certains bugs et ajouter quelques fonctionnalités manquantes.

Nous avons donc pris le temps d'améliorer le code de la phase 1 en :

    réorganisant le projet selon le modèle MVC (Modèle-Vue-Contrôleur)

    corrigeant des problèmes existants, notamment la validation du sacrifice de combinaison : auparavant, il n’était pas possible pour le joueur de refuser un sacrifice, ce comportement a été corrigé pour offrir un meilleur contrôle aux joueurs ;

## 2. Phase 2

- Fonctionnalités de base réalisées :
    Création de l'interface graphique avec JavaFX, basée sur les maquettes réalisé sur Figma
    Mise en place des écrans de jeu permettant :
      - l'affichage dynamique des dés
      - le lancement des dés
      - le choix et validation des combinaisons
      - la visualisation de la feuille de score
      
- Problèmes ou limites rencontrées :
    Quelques bugs liés au mode bonus, notamment d'intégrer correctement les cartes et de définir la manière dont il faut les utiliser
    
- Points retravaillés dans cette phase :
    Correction du problème lié à la validation du sacrifice


#### Réorganisation du code selon le modèle MVC

> Présentez :
- Le découpage logique de votre application (modèle, vue, contrôleur)
- Les classes principales et leur rôle
- Un schéma représentant la structure de votre code.



## 4. Fonctionnalités finales

> Listez ici toutes les fonctionnalités réalisées à la fin du projet.
> Pour chaque amélioration, expliquez brièvement son intérêt et sa difficulté.

- [x] Fonctionnalités de base (lancer de dés, score…)
- [x] Corrections apportées
- [ ] Version graphique (JavaFX)
- [ ] Modificateurs (jokers, rerolls…)
- [ ] Version avec cartes
- [ ] Autre idée originale : _[à décrire]_


## 5. Tests et validation

> Montrez que vous avez vérifié le bon fonctionnement :
- Cas testés (exemples)
- Résultats (succès, échecs connus)

Exemples :
- Le programme ne plante pas si l'utilisateur entre un caractère inattendu.

## 6. Difficultés rencontrées

> Soyez honnêtes : c’est ici que vous racontez ce qui a été compliqué.
> Cela peut être technique, organisationnel, ou lié à la compréhension du projet.

- Exemple : difficulté à séparer le modèle et la vue.
- Exemple : problème de communication ou de répartition dans le groupe.


## 7. Pistes d’amélioration ou d’évolution

> Proposez des pistes même si vous ne les avez pas réalisées.
> Objectif : montrer que vous avez du recul sur votre travail.
 

## ✍️ Commentaire personnel 

> Vous pouvez écrire ici ce que vous avez appris, aimé ou trouvé difficile dans cette SaÉ.

