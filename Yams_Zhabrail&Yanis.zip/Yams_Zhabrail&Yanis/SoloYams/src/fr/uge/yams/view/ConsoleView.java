package fr.uge.yams.view;

import java.util.Scanner;

import fr.uge.yams.model.Board;
import fr.uge.yams.model.ScoreSheet;

public class ConsoleView {

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void displayBoard(Board board) {
        System.out.println(board);
    }

    public int[] askDiceToReroll(Scanner scanner) {
        System.out.println("Which dice do you want to reroll? Enter numbers separated by spaces (0 to stop):");
        while (true) {
            var input = scanner.nextLine();
            var parts = input.trim().split("\\s+");
            if (parts.length == 1 && parts[0].equals("0")) {
                return new int[0];
            }
            try {
                int[] positions = new int[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    positions[i] = Integer.parseInt(parts[i]);
                    if (positions[i] < 1 || positions[i] > 5) throw new NumberFormatException();
                }
                return positions;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numbers between 1 and 5, or '0' to stop.");
            }
        }
    }

    public String askCombination(Scanner scanner) {
        System.out.println("Please choose a combination to score in your score sheet by entering its first letter:");
        return scanner.nextLine().trim().toUpperCase();
    }

    public void displayScoreSheet(ScoreSheet scoreSheet) {
        System.out.println(scoreSheet);
    }

    public void displayFinalScore(int playerScore, int aiScore) {
        System.out.println("\nGame Over!");
        System.out.println("Your final score: " + playerScore);
        System.out.println("AI final score: " + aiScore);
        if (playerScore > aiScore) {
            System.out.println("You win!");
        } else if (playerScore < aiScore) {
            System.out.println("The AI wins!");
        } else {
            System.out.println("It's a draw!");
        }
        System.out.println("Thanks for playing!");
    }
}
