package fr.uge.yams.model;

import java.util.ArrayList;
import java.util.List;

public class AIPlayer {

    // Choisit les dés à relancer pour améliorer la meilleure combinaison possible
    public int[] chooseDiceToReroll(Board board) {
        // Exemple simplifié : garde les dés de la valeur la plus fréquente, relance les autres
        List<Dice> dice = board.getDice();

        // Compte les occurrences de chaque valeur
        int[] counts = new int[7];
        for (Dice d : dice) counts[d.value()]++;

        // Trouve la valeur la plus fréquente
        int maxValue = 1;
        int maxCount = counts[1];
        for (int i = 2; i <= 6; i++) {
            if (counts[i] > maxCount) {
                maxValue = i;
                maxCount = counts[i];
            }
        }

        // Choisit de relancer tous les dés qui ne sont pas de la valeur maxValue
        List<Integer> toReroll = new ArrayList<>();
        for (int i = 0; i < dice.size(); i++) {
            if (dice.get(i).value() != maxValue) {
                toReroll.add(i + 1); // positions de 1 à 5
            }
        }

        // Convertir en tableau
        return toReroll.stream().mapToInt(Integer::intValue).toArray();
    }

    // Choisit la meilleure combinaison encore disponible
    public String chooseCombination(ScoreSheet scoreSheet, Board board) {
        String[] choices = {"Y", "L", "S", "F", "4", "T", "C"}; // Priorité aux meilleures combinaisons

        for (String choice : choices) {
            Combination combination = switch (choice) {
                case "T" -> new ThreeOfAKind();
                case "F" -> new FullHouse();
                case "C" -> new ChanceCombination();
                case "4" -> new FourOfAKind();
                case "S" -> new SmallStraight();
                case "L" -> new LargeStraight();
                case "Y" -> new YamsCombination();
                default -> null;
            };

            if (!scoreSheet.isCombinationUsed(combination) && combination.isValid(board)) {
                return choice;
            }
        }
        // Si aucune combinaison valide, choisir une non utilisée pour sacrifier
        for (String choice : choices) {
            Combination combination = switch (choice) {
                case "T" -> new ThreeOfAKind();
                case "F" -> new FullHouse();
                case "C" -> new ChanceCombination();
                case "4" -> new FourOfAKind();
                case "S" -> new SmallStraight();
                case "L" -> new LargeStraight();
                case "Y" -> new YamsCombination();
                default -> null;
            };
            if (!scoreSheet.isCombinationUsed(combination)) {
                return choice;
            }
        }
        // Fallback (normalement jamais atteint)
        return "C";
    }
}
