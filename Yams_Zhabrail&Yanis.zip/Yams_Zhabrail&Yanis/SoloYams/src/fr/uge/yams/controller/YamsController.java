package fr.uge.yams.controller;

import java.util.Scanner;

import fr.uge.yams.model.*;
import fr.uge.yams.view.ConsoleView;

public class YamsController {

    private final Scanner scanner;
    private final ConsoleView view;

    public YamsController(Scanner scanner, ConsoleView view) {
        this.scanner = scanner;
        this.view = view;
    }

    public void startGame(String playerName) {
        view.displayMessage("Hello " + playerName + ", and good luck!\n");

        ScoreSheet playerScoreSheet = new ScoreSheet();
        ScoreSheet aiScoreSheet = new ScoreSheet();
        AIPlayer aiPlayer = new AIPlayer();

        for (int round = 0; round < 7; round++) {
            view.displayMessage("\nRound " + (round + 1));

            // Tour du joueur
            view.displayMessage("\nYour turn!");
            Board playerBoard = new Board();
            view.displayBoard(playerBoard);

            for (int reroll = 0; reroll < 2; reroll++) {
                int[] diceToReroll = view.askDiceToReroll(scanner);
                if (diceToReroll.length == 0) break;
                playerBoard.reroll(diceToReroll);
                view.displayBoard(playerBoard);
            }

            Combination playerCombination = askValidCombination(playerBoard, playerScoreSheet);

            view.displayScoreSheet(playerScoreSheet);
            view.displayMessage("Your current score: " + playerScoreSheet.scoreTotal());

            // Tour de l’IA
            playAITurn(aiPlayer, aiScoreSheet);

        }

        // Fin de partie...
        view.displayFinalScore(playerScoreSheet.scoreTotal(), aiScoreSheet.scoreTotal());
    }

    private Combination askValidCombination(Board board, ScoreSheet scoreSheet) {
        while (true) {
            String input = view.askCombination(scanner);
            Combination combination;
            try {
                combination = parseCombination(input);
            } catch (IllegalArgumentException e) {
                view.displayMessage("Invalid input. Try again.");
                continue;
            }

            if (scoreSheet.isCombinationUsed(combination)) {
                view.displayMessage("This combination has already been used. Choose another one!");
                continue;
            }

            if (scoreSheet.updateScore(combination, board, scanner)) {
                return combination;
            }
            // Sinon, updateScore affiche déjà un message et on redemande
        }
    }

    private Combination parseCombination(String combinationName) {
        return switch (combinationName.toUpperCase()) {
            case "T" -> new ThreeOfAKind();
            case "F" -> new FullHouse();
            case "C" -> new ChanceCombination();
            case "4" -> new FourOfAKind();
            case "S" -> new SmallStraight();
            case "L" -> new LargeStraight();
            case "Y" -> new YamsCombination();
            default -> throw new IllegalArgumentException("Unexpected value: " + combinationName);
        };
    }

    private void playAITurn(AIPlayer aiPlayer, ScoreSheet aiScoreSheet) {
        Board aiBoard = new Board();
        view.displayMessage("\nAI's turn!");
        view.displayBoard(aiBoard);

        for (int reroll = 0; reroll < 2; reroll++) {
            int[] aiChoices = aiPlayer.chooseDiceToReroll(aiBoard);
            if (aiChoices.length == 0) break;
            aiBoard.reroll(aiChoices);
            view.displayBoard(aiBoard);
        }

        String aiChoice = aiPlayer.chooseCombination(aiScoreSheet, aiBoard);

        Combination aiCombination = parseCombination(aiChoice);

        aiScoreSheet.updateScoreIA(aiCombination, aiBoard, scanner);

        view.displayScoreSheet(aiScoreSheet);
        view.displayMessage("AI current score: " + aiScoreSheet.scoreTotal());
    }
}
